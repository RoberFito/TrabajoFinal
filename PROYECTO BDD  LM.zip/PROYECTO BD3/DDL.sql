/*DDL PROYECTO 3*/

/*
DROP TABLE SPEEDRUNNER;
DROP TABLE EQUIPO;
DROP TABLE JUEGO;
DROP TABLE JUGAR;
*/
CREATE TABLE EQUIPO(
    NOMBRE VARCHAR2(60),
    SPONSOR VARCHAR2(80),
    CONSTRAINT PK_NOM PRIMARY KEY(NOMBRE)
);

CREATE TABLE SPEEDRUNNER(
    RUNNER VARCHAR2(60),
    FECHA_NAC DATE,
    JUEGO_HAB VARCHAR2(100),
    PLATAFORMA VARCHAR2(50),
    NOM_EQUIPO VARCHAR (60),
    CONSTRAINT PK_RUNNER PRIMARY KEY(RUNNER),
    CONSTRAINT FK_EQUIPO FOREIGN KEY(NOM_EQUIPO)
    REFERENCES EQUIPO(NOMBRE)
);

CREATE TABLE JUEGO(
    NOMBRE VARCHAR2(80),
    DESARROLLADORES VARCHAR2(80),
    FECHA_SALIDA DATE,
    CONSTRAINT PK_JUEGO PRIMARY KEY(NOMBRE)
);

CREATE TABLE JUGAR(
    NOM_JUEGO VARCHAR(80) NOT NULL,
    NOM_RUNNER VARCHAR2(60) NOT NULL,
    TIEMPO NUMBER NOT NULL,
    FECHA DATE NOT NULL,
    CONSTRAINT PK_JUGAR PRIMARY KEY(NOM_JUEGO, NOM_RUNNER, FECHA),
    CONSTRAINT FK_NOM_JUEGO FOREIGN KEY(NOM_JUEGO) REFERENCES JUEGO(NOMBRE),
    CONSTRAINT FK_NOM_RUNNER FOREIGN KEY(NOM_RUNNER) REFERENCES SPEEDRUNNER(RUNNER)   
);

      create global temporary table tmp_estructura
      (id_transaccion number, 
       origen_datos varchar2(4000),
       n1 number,
       n2 number, 
       n3 number, 
       n4 number, 
       n5 number,
       n6 number,
       n7 number,
       n8 number,
       n9 number,
       n10 number,
       c1 varchar2(4000),
       c2 varchar2(4000),
       c3 varchar2(4000),
       c4 varchar2(4000), 
       c5 varchar2(4000),
       c6 varchar2(4000),
       c7 varchar2(4000),
       c9 varchar2(4000),
       c10 varchar2(4000),
       f1 date,
       f2 date,
       f3 date,
       f4 date,
       f5 date,
       f6 date,
       f7 date,
       f8 date,
       f9 date,
       f10 date
       ) on commit preserve rows;