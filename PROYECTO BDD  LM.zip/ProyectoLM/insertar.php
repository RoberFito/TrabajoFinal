<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Insertar</title>
        <link rel="stylesheet" href="estilo/estilo.css">
        <script src="scripts/scriptInsertar.js"></script>
    </head>
    <body>
        <?php
            include "conexion/conexion.php";
            $existe = false;
            if(isset($_REQUEST['equipo']))
            {
                $conexion = ConectarOracle();
                $consulta = "SELECT * FROM EQUIPO WHERE NOMBRE = '".$_REQUEST['equipo']."'";    
                $resultado = oci_parse($conexion, $consulta);
                oci_execute($resultado);                                   
                $record = oci_fetch_array($resultado);
                if(oci_num_rows($resultado) > 0)
                    $existe = true;
                
            }
        ?>
        <form name="formInsert" method="post" action="insert2.php">
            <fieldset>
                <legend>Equipo</legend>
                <label>Equipo:<input type="text" name="equipo" <?php if(isset($_REQUEST['equipo'])) echo " value='".$_REQUEST['equipo']."'";?>></label>
                <?php if(isset($_REQUEST['equipo']) && !$existe) echo "<p>El equipo no existe, insertando un nuevo equipo</p>";?>
                <label>Sponsor:<input type="text" name="sponsor" <?php if(isset($_REQUEST['equipo']) && $existe) echo " readonly value='".$record['SPONSOR']."'";?>></label>
            </fieldset>
            <fieldset>
                <legend>Speedrunner</legend>
                <label>Runner:<input type="text" name="runner"></label>
                <br><label>Juego Habitual:<br>
                    <input type="radio" name="juego" value="SUPER MARIO SUNSHINE"> Super Mario Sunshine <br>
                    <input type="radio" name="juego" value="SUPER MARIO 64"> Super Mario 64 <br>
                    <input type="radio" name="juego" value="ZELDA OCARINA OF TIME"> Zelda Ocarina of Time <br>
                    <input type="radio" name="juego" value="ZELDA BOTW"> Zelda BOTW <br>
                </label>
                <label>Plataforma:<input type="text" name="plat"></label>
                <label>Fecha nacimiento:<input type="text" name="fecha"></label>
            </fieldset>
            <input type="submit" name="grabar" value="Grabar">
        </form>
        <p><a href="index.html">Volver</a></p>
    </body>
</html>