<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">    
        <title>Estadisticas</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>
        <h1>Estadisticas</h1>
        <p><a href="esEquipo.php">Ver por Equipos</a></p>
        <p><a href="esJuego.php">Ver estadísticas de los juegos</a></p>

        <p><a href="index.html">Volver</a></p>
    </body>
</html>