<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Juegos</title>
        <link rel="stylesheet" href="estilo/estilo.css">
        <script src="scripts/scriptInsertar.js"></script>
    </head>
    <body>
        <h1>Juegos popupares</h1>
        <?php
            include "conexion/conexion.php";
            $conexion = ConectarOracle();
            $consulta = "SELECT * FROM JUEGO";    
            $resultado = oci_parse($conexion, $consulta);
            oci_execute($resultado);
            echo "<ol>";
            while($fila = oci_fetch_array($resultado))
            {
                echo "<li>".$fila['NOMBRE']." ". $fila['DESARROLLADORES']." ". $fila['FECHA_SALIDA']."</li>";
            }
            echo "</ol>";
                
            
        ?>       
        <p><a href="index.html">Volver</a></p>
    </body>
</html>