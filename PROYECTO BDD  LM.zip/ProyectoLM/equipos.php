<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Equipos</title>
        <script src="scripts/scriptEquipos.js"></script>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>
        <h1>Equipos</h1>
        <p>Selecciona un equipo y se mostrará en la siguiente pantalla los participantes de estos</p>
        <form action="grabar.php" method="post" name="grabar">
            <select name="equipos">
                <option value="default" selected hidden>Elije un equipo</option>
                <?php
                    include "conexion/conexion.php";
                    $conexion = ConectarOracle();
                    $selectEquipos = "SELECT NOMBRE FROM EQUIPO";
                    $sentencia = oci_parse($conexion, $selectEquipos);
                    oci_execute($sentencia);
                    while($fila = oci_fetch_array($sentencia)){
                        echo "<option value='".$fila['NOMBRE']."'>".$fila['NOMBRE']."</option>";
                    }
                ?>
            </select>
            <p><input type="submit" name="mostrar" value="Ver Equipo"></p>
        </form>
        <p><a href="index.html">Volver</a></p>
    </body>
</html>