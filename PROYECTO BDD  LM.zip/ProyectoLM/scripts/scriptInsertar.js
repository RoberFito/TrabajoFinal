window.onload = function() {
    let campo = document.getElementsByTagName('input')[0];

    campo.addEventListener('blur', function(){
        window.location.href="insertar.php?equipo="+campo.value;
        }
    );
        
}