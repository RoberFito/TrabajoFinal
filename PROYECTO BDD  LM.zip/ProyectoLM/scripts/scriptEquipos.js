window.onload = function(){
    let desplegable = document.grabar.equipos;
    let boton = document.grabar.mostrar;
    boton.style.display = 'none';
    desplegable.onchange = function() {boton.style.display ='inline';};
}
