<?php
    include "conexion/conexion.php";
    $conexion = ConectarOracle();



    $runner = $_REQUEST['runner'];

    

    $stid = oci_parse($conexion, 'call gestion.Madre(:1)');
    oci_bind_by_name($stid,":1", $runner);
    oci_execute($stid);

    echo "<p>Borrado con exito</p>";
    echo "<p><a href='index.html'>Volver</a></p>";
?>