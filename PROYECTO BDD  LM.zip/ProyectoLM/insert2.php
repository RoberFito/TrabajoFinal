<?php
    include "conexion/conexion.php";
    $conexion = ConectarOracle();


    $equipo = $_REQUEST['equipo'];
    $sponsor = $_REQUEST['sponsor'];
    $runner = $_REQUEST['runner'];
    $juego = $_REQUEST['juego'];
    $plat = $_REQUEST['plat'];
    $fecha = $_REQUEST['fecha'];

    $stid = oci_parse($conexion, 'call gestion.Madre(:1,:2,:3,:4,:5,:6,:7,:8)');
    oci_bind_by_name($stid,":1", $equipo);
    oci_bind_by_name($stid,":2", $sponsor);
    oci_bind_by_name($stid,":3", $runner);
    oci_bind_by_name($stid,":4", $fecha);
    oci_bind_by_name($stid,":5", $juego);
    oci_bind_by_name($stid,":6", $plat);
    oci_bind_by_name($stid,":7", $equipo);
    oci_bind_by_name($stid,":8", $mensaje, 80);
    oci_execute($stid);

    echo "<p>".$mensaje."</p>";
    echo "<p><a href='index.html'>Volver</a></p>";
?>