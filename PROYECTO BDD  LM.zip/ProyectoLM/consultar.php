<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Consultar</title>
        <style>
            body{
                background-color: darkcyan;
                color: white;
            }
            table, tr, td, th{
                border: 1px solid black;
                background-color: white;
                color: black;
            }
            a{
                font-size: large;
                text-decoration: none;
                font-weight: bold;
                color : white;
            }
        </style>
    </head>
    <body>
        <?php
            include "conexion/conexion.php";
            $conexion = ConectarOracle();                       
        ?>
        <h1>Consulta de jugadores</h1>
        <form name="consultar" action="<?=$_SERVER['PHP_SELF'];?>" method="post">
        <fieldset>
            <p><label>Speedrunner:<input type="text" name="nombre"></label><p>
        </fieldset>
        <input type="submit" name="consult">
        </form>
        <?php
            if(isset($_REQUEST['consult']))
            {
                if($_REQUEST['nombre'] != ""){
                    $stid = oci_parse($conexion, 'call Gestion.Madre(:runner,:resultado)');
                    $resultado = oci_new_cursor($conexion);
                    oci_bind_by_name($stid,":runner",$_REQUEST['nombre']);
                    oci_bind_by_name($stid,":resultado",$resultado, -1, OCI_B_CURSOR);
                    oci_execute($stid);
                    oci_execute($resultado);
                    if($resultado != null){
                        echo"<form name='modific' action='modificar.php' method='post'>";
                        echo"<table>";
                        echo "<tr><th>RUNNER</th><th>JUEGO HABITUAL</th><th>PLATAFORMA</th>
                            <th>EQUIPO</th><th>FECHA NACIMIENTO</th></tr>";
                        while($fila = oci_fetch_array($resultado, OCI_ASSOC))
                        {
                            echo "<tr><td><input type='text' name='runner' value='".$fila['C1']."' readonly></td>
                            <td><input type='text' name='juego' value='".$fila['C2']."'></td>
                            <td><input type='text' name='plat' value='".$fila['C3']."'></td>
                            <td><input type='text' name='equipo' value='".$fila['C4']."' readonly></td>
                            <td><input type='text' name='fecha' value='".$fila['F1']."' readonly></td></tr>";
                        }
                        echo "</table>";
                        echo "<input type='submit' name='modificar' value='Modificar'>";
                        echo "</form>";
                        oci_free_statement($stid);
                        oci_close($conexion);
                    }
                    else
                    {
                        echo "<p style='color:red'>Jugador no encontrado</p>";
                    }
                }
                else
                {
                    echo "<p style='color:red'>Nombre vacio</p>";
                }

            }
        ?>
        <p><a href="index.html">Volver</a></p>
    </body>
</html>