<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Modificar</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>
    <?php
        include "conexion/conexion.php";
        $conexion = ConectarOracle();
        $update = "UPDATE SPEEDRUNNER
                      SET JUEGO_HAB = '".$_REQUEST['juego']."',
                          PLATAFORMA = '".$_REQUEST['plat']."'
                    WHERE RUNNER = '".$_REQUEST['runner']."'";

        $sentencia = oci_parse($conexion, $update);
        oci_execute($sentencia);
    ?>
    <h1>Speedrunner <?=$_REQUEST['runner']?> Actualizado</h1>
    <p><a href="consultar.php">Volver</a></p>
    </body>
</html>