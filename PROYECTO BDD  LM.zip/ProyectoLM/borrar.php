<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Borrar</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>
        <h1>Borrar</h1>
        <form name="borrar" action="borrar2.php" method="post">
            <label>Inserte el nombre del Runner:<input type="text" name="runner"></label>
            <input type="submit" name="confirm">
        </form>
        <p><a href="index.html">Volver</a></p>
    </body>
</html>