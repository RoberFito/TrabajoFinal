<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">    
        <title>Por Equipos</title>
        <link rel="stylesheet" href="estilo/estilo.css">
        <style>
            table, tr, th, td{
                border : 1px solid white;
            }
        </style>
    </head>
    <body>        
        <h1>Estadisticas de <?=$_REQUEST['equipos']?></h1>
        <?php
            include "conexion/conexion.php";
            $conexion = ConectarOracle();
            $stid = oci_parse($conexion, 'call estadistica.runnerporequipo(:1,:2)');
            $resultado = oci_new_cursor($conexion);
            oci_bind_by_name($stid,":1", $_REQUEST['equipos']);
            oci_bind_by_name($stid,":2", $resultado, -1, OCI_B_CURSOR);
            
            oci_execute($stid);
            oci_execute($resultado);
            echo "<table>";
            echo "<tr><th>RUNNER</th><th>FECHA NACIMIENTO</th><th>PLATAFORMA</th><th>JUGADOS</th><th>TOTAL MINUTOS JUGADOS</th></tr>";
            while($fila = oci_fetch_array($resultado, OCI_ASSOC))
            {
                echo "<tr><td>".$fila['C1']."</td>
                <td>".$fila['F1']."</td>
                <td>".$fila['C2']."</td>
                <td>".$fila['C3']."</td>
                <td>".$fila['N1']."</td></tr>";
            }
            echo "</table>";
        ?>
        <p><a href="index.html">Volver</a></p>
    </body>
</html>