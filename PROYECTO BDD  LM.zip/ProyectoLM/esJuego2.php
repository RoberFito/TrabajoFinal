<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">    
        <title>Por Equipos</title>
        <link rel="stylesheet" href="estilo/estilo.css">
        <style>
            table, tr, th, td{
                border : 1px solid white;
            }
        </style>
    </head>
    <body>        
        <h1>Estadisticas de <?=$_REQUEST['juegos']?></h1>
        <?php
            include "conexion/conexion.php";
            $conexion = ConectarOracle();
            $stid = oci_parse($conexion, 'call estadistica.esta_juegos(:1,:2)');
            $resultado = oci_new_cursor($conexion);
            oci_bind_by_name($stid,":1", $_REQUEST['juegos']);
            oci_bind_by_name($stid,":2", $resultado, -1, OCI_B_CURSOR);
            
            oci_execute($stid);
            oci_execute($resultado);
            echo "<table>";
            echo "<tr><th>PARTIDAS</th><th>MEJOR RUNNER</th><th>RECORD</th><th>MAS LENTO</th></tr>";
            while($fila = oci_fetch_array($resultado, OCI_ASSOC))
            {
                echo "<tr><td>".$fila['N1']."</td>
                <td>".$fila['C1']."</td>
                <td>".$fila['N2']."</td>
                <td>".$fila['N3']."</td></tr>";
            }
            echo "</table>";
        ?>
        <p><a href="index.html">Volver</a></p>
    </body>
</html>