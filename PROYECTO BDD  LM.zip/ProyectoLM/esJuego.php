<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">    
        <title>Por Juegos</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>        
        <h1>Estadisticas de los juegos</h1>
        <p>Selecciona el equipo</p>
        <form  action="esJuego2.php" method="post" name="porJuego">
            <select name="juegos">
                <?php
                    include "conexion/conexion.php";
                    $conexion = ConectarOracle();
                    $consulta = "SELECT NOMBRE FROM JUEGO";
                    $resultado = oci_parse($conexion,$consulta);
                    oci_execute($resultado);
                    while($record = oci_fetch_array($resultado))
                    {
                        echo "<option value='".$record['NOMBRE']."'>".$record['NOMBRE']."</option>";
                    }
                ?>
            </select>
            <input type="submit" name="ver" value="Ver resultado">
        </form>
    </body>
</html>