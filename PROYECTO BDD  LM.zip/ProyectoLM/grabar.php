<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">            
        <title>Equipo</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>
        <h1>Equipo <?=$_REQUEST['equipos']?></h1>
        <p>Pulsa el botón de alguno de los jugadores para ver más sobre él.</p>
        <ul>
            <?php
                include "conexion/conexion.php";
                $conexion = ConectarOracle();
                $consulta = "SELECT RUNNER, JUEGO_HAB, FECHA_NAC FROM SPEEDRUNNER WHERE NOM_EQUIPO ='".$_REQUEST['equipos']."'";
                $sentencia = oci_parse($conexion, $consulta);
                oci_execute($sentencia);
                while($resultado = oci_fetch_array($sentencia))
                {
                    echo "<li>".$resultado['RUNNER']." "
                    .$resultado['JUEGO_HAB']." "
                    .$resultado['FECHA_NAC']." <a href='estadistica.php?runner=".$resultado['RUNNER']."'><input type='button'></a></li>";
                }
            ?>
        </ul>
    </body>
</html>