<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">    
        <title>Por Equipos</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>
    <body>        
        <h1>Estadisticas por Equipos</h1>
        <p>Selecciona el equipo</p>
        <form  action="esEquipo2.php" method="post" name="porEquipo">
            <select name="equipos">
                <?php
                    include "conexion/conexion.php";
                    $conexion = ConectarOracle();
                    $consulta = "SELECT NOMBRE FROM EQUIPO";
                    $resultado = oci_parse($conexion,$consulta);
                    oci_execute($resultado);
                    while($record = oci_fetch_array($resultado))
                    {
                        echo "<option value='".$record['NOMBRE']."'>".$record['NOMBRE']."</option>";
                    }
                ?>
            </select>
            <input type="submit" name="ver" value="Ver resultado">
        </form>
    </body>
</html>