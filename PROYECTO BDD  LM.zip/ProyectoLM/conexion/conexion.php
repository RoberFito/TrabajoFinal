<?php
    function ConectarOracle()
    {
        $idCone = oci_connect('PFSPEEDRUN', '1234', '192.168.46.128/XE', 'UTF8');
        //echo "Conectado con éxito";
        return $idCone;
    }
?>